/**
 * AI Text Explainer — Content Script
 *
 * 流程：
 * 1) mouseup → window.getSelection() 取划选文本与 Range 矩形（视口坐标）
 * 2) 在 Shadow DOM 内显示「AI 解释」浮动按钮（position: fixed）
 * 3) 点击按钮 → 通过 runtime.connect 交给 background.js 直调大模型 API（SSE 流式）。
 */

(() => {
  "use strict";

  /* ===================================================================
   * 日志工具
   * =================================================================== */
  const log = {
    debug: (...args) => console.debug("[AI Explainer:Content]", ...args),
    info: (...args) => console.info("[AI Explainer:Content]", ...args),
    warn: (...args) => console.warn("[AI Explainer:Content]", ...args),
    error: (...args) => console.error("[AI Explainer:Content]", ...args),
  };

  const ext = globalThis.browser ?? globalThis.chrome;

  const STREAM_TIMEOUT_MS = 120000;
  const SELECTION_DEBOUNCE_MS = 48;
  const MAX_CONTEXT_CHARS = 6000;

  let shadowHost = null;
  /** @type {ShadowRoot | null} */
  let shadowRoot = null;
  let cssLoadedPromise = null;

  /**
   * 拖动解释卡片。
   */
  function wireCardDrag(card, header) {
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    function clamp(n, lo, hi) {
      return Math.min(Math.max(n, lo), hi);
    }

    function onMove(ev) {
      if (!dragging) return;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const cw = card.offsetWidth;
      const ch = card.offsetHeight;
      let left = ev.clientX - offsetX;
      let top = ev.clientY - offsetY;
      left = clamp(left, 8, Math.max(8, vw - cw - 8));
      top = clamp(top, 8, Math.max(8, vh - ch - 8));
      card.style.left = `${left}px`;
      card.style.top = `${top}px`;
    }

    function onUp() {
      if (!dragging) return;
      dragging = false;
      card.classList.remove("ai-dragging");
      window.removeEventListener("pointermove", onMove, true);
      window.removeEventListener("pointerup", onUp, true);
      window.removeEventListener("pointercancel", onUp, true);
    }

    header.addEventListener(
      "pointerdown",
      (ev) => {
        if (card.dataset.open !== "true") return;
        if (ev.button !== 0) return;
        const close = header.querySelector(".ai-close");
        if (close && (ev.target === close || close.contains(/** @type {Node} */ (ev.target)))) {
          return;
        }

        ev.preventDefault();
        dragging = true;
        card.classList.add("ai-dragging");
        const r = card.getBoundingClientRect();
        offsetX = ev.clientX - r.left;
        offsetY = ev.clientY - r.top;

        window.addEventListener("pointermove", onMove, true);
        window.addEventListener("pointerup", onUp, true);
        window.addEventListener("pointercancel", onUp, true);
      },
      true,
    );
  }

  let debounceTimer = 0;
  /** @type {{ text: string; context: string; rect: DOMRect } | null} */
  let pendingExplain = null;

  /** 当前流式请求的中止控制器 */
  let streamAbortController = null;

  function loadCssIntoShadow(sr) {
    if (!cssLoadedPromise) {
      const url = ext.runtime.getURL("popup.css");
      cssLoadedPromise = fetch(url)
        .then((r) => {
          if (!r.ok) throw new Error(`加载 popup.css 失败: ${r.status}`);
          return r.text();
        })
        .then((text) => {
          const style = document.createElement("style");
          style.textContent = text;
          sr.appendChild(style);
        })
        .catch((e) => {
          log.error("加载 popup.css 失败，使用备用样式", e);
          const style = document.createElement("style");
          style.textContent =
            ":host{font-family:system-ui,sans-serif}.ai-card{padding:12px;background:#fff;color:#111}";
          sr.appendChild(style);
        });
    }
    return cssLoadedPromise;
  }

  function ensureUi() {
    if (shadowHost && shadowRoot) return shadowRoot;

    shadowHost = document.createElement("div");
    shadowHost.id = "ai-text-explainer-extension-root";
    shadowRoot = shadowHost.attachShadow({ mode: "open" });
    document.documentElement.appendChild(shadowHost);
    log.debug("Shadow DOM 已创建");

    const root = document.createElement("div");
    root.className = "ai-root";

    const fab = document.createElement("button");
    fab.type = "button"; fab.className = "ai-fab"; fab.id = "aiFab"; fab.setAttribute("aria-label", "AI 解释");
    fab.textContent = "AI 解释";
    root.appendChild(fab);

    const overlay = document.createElement("div");
    overlay.className = "ai-overlay"; overlay.id = "aiOverlay"; overlay.dataset.open = "false";
    root.appendChild(overlay);

    const section = document.createElement("section");
    section.className = "ai-card"; section.id = "aiCard"; section.dataset.open = "false";
    section.setAttribute("role", "dialog"); section.setAttribute("aria-modal", "true");
    section.setAttribute("aria-labelledby", "aiCardTitle");

    const header = document.createElement("header");
    header.className = "ai-card-header";
    const title = document.createElement("h2");
    title.className = "ai-card-title"; title.id = "aiCardTitle"; title.textContent = "词汇解释";
    header.appendChild(title);
    const closeBtn = document.createElement("button");
    closeBtn.type = "button"; closeBtn.className = "ai-close"; closeBtn.id = "aiClose";
    closeBtn.setAttribute("aria-label", "关闭"); closeBtn.textContent = "×";
    header.appendChild(closeBtn);
    section.appendChild(header);

    const selPreview = document.createElement("div");
    selPreview.className = "ai-selection-preview"; selPreview.id = "aiSelPreview";
    section.appendChild(selPreview);

    const body = document.createElement("div");
    body.className = "ai-body ai-loading"; body.id = "aiBody"; body.textContent = "生成解释中…";
    section.appendChild(body);

    const errEl = document.createElement("div");
    errEl.className = "ai-error"; errEl.id = "aiError"; errEl.hidden = true;
    section.appendChild(errEl);

    const footer = document.createElement("div");
    footer.className = "ai-footer-hint"; footer.textContent = "流式输出 · 拖动标题栏移动 · 点击空白关闭";
    section.appendChild(footer);

    root.appendChild(section);
    shadowRoot.appendChild(root);

    const card = section;
    if (card && header) wireCardDrag(card, header);

    fab.addEventListener("click", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      if (!pendingExplain?.text) return;
      log.info("用户点击 AI 解释按钮", { text: pendingExplain.text.slice(0, 60) });
      const payload = { ...pendingExplain };
      openPanel(payload);
      void runStream(payload);
    });

    function closePanel() {
      streamAbortController?.abort();
      streamAbortController = null;
      overlay.dataset.open = "false";
      card.dataset.open = "false";
      pendingExplain = null;
      hideFab(shadowRoot);
    }

    closeBtn.addEventListener("click", (ev) => {
      ev.preventDefault();
      log.debug("用户关闭解释面板");
      closePanel();
    });

    overlay.addEventListener("click", () => closePanel());
    card.addEventListener("click", (ev) => ev.stopPropagation());

    return shadowRoot;
  }

  function getContextAroundSelection(sel, selectedText, maxLen) {
    if (!sel.rangeCount) return "";
    const range = sel.getRangeAt(0);
    let node = range.commonAncestorContainer;
    const el =
      node.nodeType === Node.ELEMENT_NODE
        ? /** @type {Element} */ (node)
        : node.parentElement;
    const block =
      el?.closest?.(
        "article,section,main,p,li,td,th,blockquote,pre,code,[role='article']",
      ) ?? el?.closest?.("div") ?? document.body;
    let full = "";
    try {
      full = block.innerText ?? block.textContent ?? "";
    } catch {
      full = document.body.innerText ?? "";
    }
    full = full.replace(/\s+/g, " ").trim();
    const idx = full.indexOf(selectedText);
    const half = Math.max(0, Math.floor((maxLen - selectedText.length) / 2));
    if (idx === -1) return full.slice(0, maxLen);
    const start = Math.max(0, idx - half);
    return full.slice(start, start + maxLen);
  }

  function hideFab(sr) {
    if (!sr) return;
    const fab = sr.getElementById("aiFab");
    if (!fab) return;
    fab.dataset.visible = "false";
    pendingExplain = null;
  }

  function placeFab(sr, rect) {
    const fab = sr.getElementById("aiFab");
    if (!fab) return;
    const pad = 6;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    fab.dataset.visible = "true";
    fab.style.left = "0";
    fab.style.top = "0";
    void fab.offsetWidth;
    const bw = fab.offsetWidth || 88;
    const bh = fab.offsetHeight || 32;

    let vx = rect.left + pad;
    let vy = rect.bottom + pad;
    if (vx + bw > vw - 8) vx = Math.max(8, vw - bw - 8);
    if (vy + bh > vh - 8) vy = Math.max(8, rect.top - bh - pad);
    fab.style.left = `${vx}px`;
    fab.style.top = `${vy}px`;
  }

  function handleSelectionChange() {
    const sr = ensureUi();
    const sel = window.getSelection();
    const text = sel?.toString()?.trim() ?? "";

    if (!text || !sel || sel.rangeCount === 0) {
      hideFab(sr);
      return;
    }

    const range = sel.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    if (rect.width < 2 && rect.height < 2) {
      hideFab(sr);
      return;
    }

    const contextRaw = getContextAroundSelection(sel, text, MAX_CONTEXT_CHARS);
    pendingExplain = {
      text,
      context: contextRaw.slice(0, MAX_CONTEXT_CHARS),
      rect,
    };
    placeFab(sr, rect);
  }

  function onMouseUp(ev) {
    if (ev.button !== 0) return;
    window.clearTimeout(debounceTimer);
    debounceTimer = window.setTimeout(() => {
      window.requestAnimationFrame(() => handleSelectionChange());
    }, SELECTION_DEBOUNCE_MS);
  }

  /** 滚动或缩放时隐藏按钮 */
  function onViewportChange() {
    const sr = shadowRoot;
    if (sr) hideFab(sr);
  }

  function openPanel(payload) {
    const sr = ensureUi();
    const fab = sr.getElementById("aiFab");
    if (fab) fab.dataset.visible = "false";

    const overlay = sr.getElementById("aiOverlay");
    const card = sr.getElementById("aiCard");
    const preview = sr.getElementById("aiSelPreview");
    const body = sr.getElementById("aiBody");
    const errEl = sr.getElementById("aiError");

    overlay.dataset.open = "true";
    card.dataset.open = "true";

    const r = payload.rect;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const cw = Math.min(420, vw - 32);
    let cx = r.right + 12;
    let cy = r.top;
    if (cx + cw > vw - 16) cx = Math.max(16, r.left - cw - 12);
    if (cx < 16) cx = 16;
    cy = Math.max(16, Math.min(cy, vh - 120));
    card.style.left = `${cx}px`;
    card.style.top = `${cy}px`;

    preview.textContent = "";
    const strong = document.createElement("strong");
    strong.textContent = "划选";
    preview.appendChild(strong);
    preview.appendChild(document.createTextNode("：" + payload.text.slice(0, 200) + (payload.text.length > 200 ? "…" : "")));
    body.textContent = "";
    body.classList.add("ai-loading");
    errEl.hidden = true;
    errEl.textContent = "";

    const cursor = document.createElement("span");
    cursor.className = "ai-cursor";
    body.appendChild(cursor);
  }

  /**
   * 经后台脚本直调大模型 API。
   */
  function streamExplainViaBackground(
    text,
    context,
    onChunk,
    onError,
    outerSignal,
  ) {
    return new Promise((resolve) => {
      let settled = false;
      let port;

      const finish = () => {
        if (settled) return;
        settled = true;
        outerSignal?.removeEventListener("abort", onAbort);
        resolve();
      };

      const onAbort = () => {
        try {
          port?.disconnect();
        } catch {
          /* 端口可能已关闭 */
        }
        finish();
      };

      if (outerSignal?.aborted) {
        finish();
        return;
      }
      outerSignal?.addEventListener("abort", onAbort, { once: true });

      try {
        port = ext.runtime.connect({ name: "ai-explainer-sse" });
      } catch (e) {
        log.error("runtime.connect 失败", e);
        onError("无法连接扩展后台，请在 about:debugging 中重新加载本扩展。");
        finish();
        return;
      }

      port.onMessage.addListener(function onMsg(msg) {
        if (!msg || typeof msg !== "object") return;
        if (msg.type === "chunk" && msg.text) onChunk(String(msg.text));
        if (msg.type === "error" && msg.message) {
          log.error("后台返回错误", msg.message);
          onError(String(msg.message));
        }
        if (msg.type === "done") {
          port.onMessage.removeListener(onMsg);
          try {
            port.disconnect();
          } catch {
            /* 可能已断开 */
          }
          finish();
        }
      });

      port.onDisconnect.addListener(() => {
        port.onMessage.removeListener(onMsg);
        finish();
      });

      try {
        port.postMessage({
          type: "start",
          text,
          context,
          timeoutMs: STREAM_TIMEOUT_MS,
        });
      } catch (e) {
        log.error("port.postMessage 失败", e);
        onError("无法连接扩展后台，请在 about:debugging 中重新加载本扩展。");
        try {
          port.disconnect();
        } catch {
          /* 可能已断开 */
        }
        finish();
      }
    });
  }

  async function runStream(payload) {
    const sr = ensureUi();
    const body = sr.getElementById("aiBody");
    const errEl = sr.getElementById("aiError");

    streamAbortController?.abort();
    streamAbortController = new AbortController();
    const outerSignal = streamAbortController.signal;

    await loadCssIntoShadow(sr);

    let plain = "";
    const applyBody = () => {
      body.classList.remove("ai-loading");
      body.textContent = plain;
      const cursor = document.createElement("span");
      cursor.className = "ai-cursor";
      body.appendChild(cursor);
    };

    const onChunk = (chunk) => {
      plain += chunk;
      applyBody();
    };

    const onError = (msg) => {
      if (outerSignal.aborted) return;
      errEl.hidden = false;
      errEl.textContent = msg;
      body.classList.remove("ai-loading");
      const cursor = body.querySelector(".ai-cursor");
      if (cursor) cursor.remove();
    };

    await streamExplainViaBackground(
      payload.text,
      payload.context,
      onChunk,
      onError,
      outerSignal,
    );

    streamAbortController = null;

    const cursor = body.querySelector(".ai-cursor");
    if (cursor) cursor.remove();
  }

  function cleanup() {
    log.info("页面卸载，清理 content script 资源");
    streamAbortController?.abort();
    streamAbortController = null;

    if (shadowHost && shadowHost.parentNode) {
      shadowHost.parentNode.removeChild(shadowHost);
    }
    shadowHost = null;
    shadowRoot = null;
    cssLoadedPromise = null;
    pendingExplain = null;

    window.clearTimeout(debounceTimer);

    document.removeEventListener("mouseup", onMouseUp, true);
    window.removeEventListener("scroll", onViewportChange, true);
    window.removeEventListener("resize", onViewportChange);
  }

  async function init() {
    log.info("初始化 content script");

    ensureUi();
    await loadCssIntoShadow(shadowRoot);

    document.addEventListener("mouseup", onMouseUp, { passive: true });
    document.addEventListener(
      "keyup",
      () => {
        window.clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(() => {
          window.requestAnimationFrame(() => handleSelectionChange());
        }, SELECTION_DEBOUNCE_MS + 40);
      },
      { passive: true },
    );
    window.addEventListener("scroll", onViewportChange, {
      passive: true,
      capture: true,
    });
    window.addEventListener("resize", onViewportChange, { passive: true });

    // 页面卸载时清理资源
    window.addEventListener("beforeunload", cleanup);
    window.addEventListener("pagehide", cleanup);

    log.info("content script 就绪");
  }

  void init();
})();