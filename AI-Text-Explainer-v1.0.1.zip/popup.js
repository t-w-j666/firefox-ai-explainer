(function () {
  "use strict";

  const browserApi = globalThis.browser ?? globalThis.chrome;

  /* ===================================================================
   * 日志工具
   * =================================================================== */
  const log = {
    debug: (...args) => console.debug("[AI Explainer:Popup]", ...args),
    info: (...args) => console.info("[AI Explainer:Popup]", ...args),
    warn: (...args) => console.warn("[AI Explainer:Popup]", ...args),
    error: (...args) => console.error("[AI Explainer:Popup]", ...args),
  };

  const $ = (id) => document.getElementById(id);
  const DEFAULTS = {
    apiBaseUrl: "https://api.deepseek.com",
    modelName: "deepseek-chat",
  };

  // ---- 内部状态 ----
  let profiles = [];
  let activeId = null;
  let isNewProfile = false;

  // ---- 存储读写 ----
  const STORE_KEY_PROFILES = "apiProfiles";
  const STORE_KEY_ACTIVE = "activeProfileId";

  function genId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  /** 迁移旧版扁平配置 → profiles 数组 */
  async function migrateIfNeeded() {
    const existing = await browserApi.storage.local.get([STORE_KEY_PROFILES, "apiKey", "apiBaseUrl", "modelName"]);
    if (existing[STORE_KEY_PROFILES] && existing[STORE_KEY_PROFILES].length > 0) return; // 已有 profiles

    const oldKey = (existing.apiKey || "").trim();
    const oldUrl = ((existing.apiBaseUrl || DEFAULTS.apiBaseUrl).trim()).replace(/\/+$/, "");
    const oldModel = (existing.modelName || DEFAULTS.modelName).trim();

    if (!oldKey && !existing[STORE_KEY_PROFILES]) return; // 完全空，无需迁移

    const defaultProfile = {
      id: genId(),
      name: "默认方案",
      apiKey: oldKey,
      apiBaseUrl: oldUrl || DEFAULTS.apiBaseUrl,
      modelName: oldModel || DEFAULTS.modelName,
    };

    await browserApi.storage.local.set({
      [STORE_KEY_PROFILES]: [defaultProfile],
      [STORE_KEY_ACTIVE]: defaultProfile.id,
    });
  }

  async function loadFromStorage() {
    await migrateIfNeeded();

    const obj = await browserApi.storage.local.get([STORE_KEY_PROFILES, STORE_KEY_ACTIVE]);
    profiles = obj[STORE_KEY_PROFILES] || [];
    activeId = obj[STORE_KEY_ACTIVE] || null;

    // 保证 activeId 指向一个实际存在的 profile
    if (activeId && !profiles.some(p => p.id === activeId)) {
      activeId = profiles.length > 0 ? profiles[0].id : null;
    }

    log.debug("已加载配置方案", { count: profiles.length, activeId });
  }

  async function persist() {
    await browserApi.storage.local.set({
      [STORE_KEY_PROFILES]: profiles,
      [STORE_KEY_ACTIVE]: activeId,
    });
  }

  function findActive() {
    return profiles.find(p => p.id === activeId) || null;
  }

  // ---- UI 渲染 ----
  function renderProfileSelect() {
    const sel = $("profileSelect");
    sel.textContent = "";

    if (profiles.length === 0) {
      const opt = document.createElement("option");
      opt.textContent = "（暂无配置）";
      opt.disabled = true;
      sel.appendChild(opt);
    } else {
      profiles.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = p.name;
        if (p.id === activeId) opt.selected = true;
        sel.appendChild(opt);
      });
    }

    $("deleteProfileBtn").disabled = profiles.length <= 1;
  }

  function loadFormFromProfile() {
    const p = findActive();
    if (!p) {
      clearForm();
      $("profileName").value = "";
      $("profileNameField").style.display = isNewProfile ? "" : "none";
      return;
    }

    $("apiKey").value = p.apiKey || "";
    $("apiBaseUrl").value = p.apiBaseUrl || DEFAULTS.apiBaseUrl;
    $("modelName").value = p.modelName || DEFAULTS.modelName;
    $("profileName").value = p.name || "";
    $("profileNameField").style.display = isNewProfile ? "" : "none";

    updateStatusDot(!!p.apiKey);
    updateModelHint(p.modelName);
  }

  function clearForm() {
    $("apiKey").value = "";
    $("apiBaseUrl").value = DEFAULTS.apiBaseUrl;
    $("modelName").value = DEFAULTS.modelName;
    $("profileName").value = "";
    $("modelHint").textContent = "";
    updateStatusDot(false);
  }

  function updateStatusDot(hasKey) {
    const dot = $("statusDot");
    dot.className = "status-dot" + (hasKey ? " ok" : " fail");
    dot.title = hasKey ? "API Key 已配置" : "未配置 API Key";
  }

  function updateModelHint(model) {
    const el = $("modelHint");
    el.textContent = model && model !== DEFAULTS.modelName
      ? `当前模型：${model}`
      : "";
  }

  // ---- 操作 ----
  async function selectProfile(id) {
    if (id === activeId && !isNewProfile) return;
    isNewProfile = false;
    activeId = id;
    $("profileNameField").style.display = "none";
    loadFormFromProfile();
    await persist();
    log.debug("切换到配置方案", id);
  }

  async function newProfile() {
    isNewProfile = true;
    activeId = null;

    const sel = $("profileSelect");
    sel.value = "";
    if (!sel.querySelector('option[value=""]')) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "（新建中…）";
      opt.selected = true;
      sel.insertBefore(opt, sel.firstChild);
    } else {
      sel.value = "";
    }

    clearForm();
    $("profileNameField").style.display = "";
    $("profileName").focus();
    $("deleteProfileBtn").disabled = true;
    log.debug("新建配置方案");
  }

  async function saveProfile() {
    const name = $("profileName").value.trim();
    const apiKey = $("apiKey").value.trim();
    const apiBaseUrl = $("apiBaseUrl").value.trim().replace(/\/+$/, "");
    const modelName = $("modelName").value.trim();

    if (!name) {
      showMsg("请填写方案名称", true);
      $("profileName").focus();
      return;
    }
    if (!apiKey) {
      showMsg("请填写 API Key", true);
      return;
    }

    if (isNewProfile) {
      // 创建新 profile
      const p = { id: genId(), name, apiKey, apiBaseUrl: apiBaseUrl || DEFAULTS.apiBaseUrl, modelName };
      profiles.push(p);
      activeId = p.id;
      isNewProfile = false;
    } else if (activeId) {
      // 更新已有 profile
      const p = findActive();
      if (p) {
        p.name = name;
        p.apiKey = apiKey;
        p.apiBaseUrl = apiBaseUrl || DEFAULTS.apiBaseUrl;
        p.modelName = modelName;
      }
    } else {
      showMsg("请先选择或新建配置方案", true);
      return;
    }

    await persist();

    // 去掉"新建中"占位项
    const sel = $("profileSelect");
    const placeholder = sel.querySelector('option[value=""]');
    if (placeholder) placeholder.remove();

    renderProfileSelect();
    $("profileNameField").style.display = "none";
    updateStatusDot(true);
    updateModelHint(modelName);
    log.info("保存配置方案", { name, modelName, isNew: !activeId || isNewProfile === false });
    showMsg("✓ 已保存", false);
  }

  async function deleteProfile() {
    if (profiles.length <= 1) {
      showMsg("至少保留一个配置方案", true);
      return;
    }

    const p = findActive();
    if (!p) return;

    const confirmed = confirm(`确定要删除配置方案"${p.name}"吗？`);
    if (!confirmed) return;

    const idx = profiles.findIndex(x => x.id === activeId);
    if (idx === -1) return;

    profiles.splice(idx, 1);

    // 切换到相邻 profile
    activeId = profiles[Math.min(idx, profiles.length - 1)].id;

    await persist();
    renderProfileSelect();
    loadFormFromProfile();
    log.info("已删除配置方案", { name: p.name });
    showMsg("已删除", false);
  }

  // ---- 测试连接 ----
  async function test() {
    const apiKey = $("apiKey").value.trim();
    const apiBaseUrl = $("apiBaseUrl").value.trim().replace(/\/+$/, "");
    const modelName = $("modelName").value.trim();

    if (!apiKey || !apiBaseUrl || !modelName) {
      showMsg("请先填写完整配置", true);
      return;
    }

    const btn = $("testBtn");
    btn.disabled = true;
    btn.textContent = "测试中…";
    $("statusDot").className = "status-dot loading";

    log.debug("测试连接", { apiBaseUrl, modelName });

    try {
      const res = await fetch(`${apiBaseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: modelName,
          messages: [{ role: "user", content: "回复ok" }],
          stream: false,
          max_tokens: 10,
        }),
      });

      if (!res.ok) {
        const text = await res.text();
        log.warn("测试连接失败", { status: res.status, detail: text.slice(0, 120) });
        showMsg(`✗ ${res.status} ${text.slice(0, 120)}`, true);
        $("statusDot").className = "status-dot fail";
        return;
      }

      log.info("测试连接成功", { apiBaseUrl, modelName });
      showMsg("✓ 连接成功", false);
      $("statusDot").className = "status-dot ok";
    } catch (err) {
      log.error("测试连接异常", err.message);
      showMsg(`✗ ${err.message}`, true);
      $("statusDot").className = "status-dot fail";
    } finally {
      btn.disabled = false;
      btn.textContent = "测试";
    }
  }

  // ---- 打开完整设置页 ----
  function openOptions() {
    if (browserApi.runtime.openOptionsPage) {
      browserApi.runtime.openOptionsPage();
    } else {
      window.open(browserApi.runtime.getURL("options.html"));
    }
    window.close();
  }

  // ---- 打开日志页 ----
  function openLogPage() {
    const url = browserApi.runtime.getURL("log.html");
    window.open(url);
    window.close();
  }

  function showMsg(text, isError) {
    const el = $("statusMsg");
    el.textContent = text;
    el.className = "status-msg visible" + (isError ? " error" : "");
    if (!isError) {
      setTimeout(() => el.classList.remove("visible"), 2500);
    }
  }

  // ---- 初始化 ----
  document.addEventListener("DOMContentLoaded", async () => {
    await loadFromStorage();
    renderProfileSelect();
    loadFormFromProfile();

    $("profileSelect").addEventListener("change", () => {
      const id = $("profileSelect").value;
      if (id) selectProfile(id);
    });

    $("newProfileBtn").addEventListener("click", newProfile);
    $("deleteProfileBtn").addEventListener("click", deleteProfile);
    $("saveBtn").addEventListener("click", saveProfile);
    $("testBtn").addEventListener("click", test);

    $("openOptions").addEventListener("click", (e) => {
      e.preventDefault();
      openOptions();
    });

    $("openLog").addEventListener("click", (e) => {
      e.preventDefault();
      openLogPage();
    });
  });
})();