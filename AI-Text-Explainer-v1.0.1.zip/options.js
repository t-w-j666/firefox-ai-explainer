(function () {
  "use strict";

  const browserApi = globalThis.browser ?? globalThis.chrome;

  /* ===================================================================
   * 日志工具
   * =================================================================== */
  const log = {
    debug: (...args) => console.debug("[AI Explainer:Options]", ...args),
    info: (...args) => console.info("[AI Explainer:Options]", ...args),
    warn: (...args) => console.warn("[AI Explainer:Options]", ...args),
    error: (...args) => console.error("[AI Explainer:Options]", ...args),
  };

  const $ = (id) => document.getElementById(id);
  const DEFAULTS = {
    apiKey: "",
    apiBaseUrl: "https://api.deepseek.com",
    modelName: "deepseek-chat",
  };

  // ---- 内部状态 ----
  let profiles = [];
  let activeId = null;
  let isNewProfile = false;

  // ---- 存储读写 ----
  const STORE_KEY_PROFILES = "apiProfiles";
  const STORE_KEY_ACTIVE = "activeProfileId";

  function genId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  async function migrateIfNeeded() {
    const existing = await browserApi.storage.local.get([STORE_KEY_PROFILES, "apiKey", "apiBaseUrl", "modelName"]);
    if (existing[STORE_KEY_PROFILES] && existing[STORE_KEY_PROFILES].length > 0) return;

    const oldKey = (existing.apiKey || "").trim();
    const oldUrl = ((existing.apiBaseUrl || DEFAULTS.apiBaseUrl).trim()).replace(/\/+$/, "");
    const oldModel = (existing.modelName || DEFAULTS.modelName).trim();

    if (!oldKey && !existing[STORE_KEY_PROFILES]) return;

    const defaultProfile = {
      id: genId(),
      name: "默认方案",
      apiKey: oldKey,
      apiBaseUrl: oldUrl || DEFAULTS.apiBaseUrl,
      modelName: oldModel || DEFAULTS.modelName,
    };

    await browserApi.storage.local.set({
      [STORE_KEY_PROFILES]: [defaultProfile],
      [STORE_KEY_ACTIVE]: defaultProfile.id,
    });
  }

  async function loadFromStorage() {
    await migrateIfNeeded();

    const obj = await browserApi.storage.local.get([STORE_KEY_PROFILES, STORE_KEY_ACTIVE]);
    profiles = obj[STORE_KEY_PROFILES] || [];
    activeId = obj[STORE_KEY_ACTIVE] || null;

    if (activeId && !profiles.some(p => p.id === activeId)) {
      activeId = profiles.length > 0 ? profiles[0].id : null;
    }

    log.debug("已加载配置方案", { count: profiles.length, activeId });
  }

  async function persist() {
    await browserApi.storage.local.set({
      [STORE_KEY_PROFILES]: profiles,
      [STORE_KEY_ACTIVE]: activeId,
    });
  }

  function findActive() {
    return profiles.find(p => p.id === activeId) || null;
  }

  // ---- UI 渲染 ----
  function renderProfileSelect() {
    const sel = $("profileSelect");
    sel.textContent = "";

    if (profiles.length === 0) {
      const opt = document.createElement("option");
      opt.textContent = "（暂无配置）";
      opt.disabled = true;
      sel.appendChild(opt);
    } else {
      profiles.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = p.name;
        if (p.id === activeId) opt.selected = true;
        sel.appendChild(opt);
      });
    }

    $("deleteProfileBtn").disabled = profiles.length <= 1;
  }

  function loadFormFromProfile() {
    const p = findActive();
    if (!p) {
      $("apiKey").value = "";
      $("apiBaseUrl").value = DEFAULTS.apiBaseUrl;
      $("modelName").value = DEFAULTS.modelName;
      $("profileName").value = "";
      $("profileNameField").style.display = isNewProfile ? "" : "none";
      return;
    }

    $("apiKey").value = p.apiKey || "";
    $("apiBaseUrl").value = p.apiBaseUrl || DEFAULTS.apiBaseUrl;
    $("modelName").value = p.modelName || DEFAULTS.modelName;
    $("profileName").value = p.name || "";
    $("profileNameField").style.display = isNewProfile ? "" : "none";
  }

  function clearForm() {
    $("apiKey").value = "";
    $("apiBaseUrl").value = DEFAULTS.apiBaseUrl;
    $("modelName").value = DEFAULTS.modelName;
    $("profileName").value = "";
  }

  // ---- 操作 ----
  async function selectProfile(id) {
    if (id === activeId && !isNewProfile) return;
    isNewProfile = false;
    activeId = id;
    $("profileNameField").style.display = "none";
    loadFormFromProfile();
    await persist();
    log.debug("切换到配置方案", id);
  }

  async function newProfile() {
    isNewProfile = true;
    activeId = null;

    const sel = $("profileSelect");
    sel.value = "";
    if (!sel.querySelector('option[value=""]')) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "（新建中…）";
      opt.selected = true;
      sel.insertBefore(opt, sel.firstChild);
    } else {
      sel.value = "";
    }

    clearForm();
    $("profileNameField").style.display = "";
    $("profileName").focus();
    $("deleteProfileBtn").disabled = true;
    log.debug("新建配置方案");
  }

  async function saveProfile() {
    const name = $("profileName").value.trim();
    const apiKey = $("apiKey").value.trim();
    const apiBaseUrl = $("apiBaseUrl").value.trim().replace(/\/+$/, "");
    const modelName = $("modelName").value.trim();

    if (!name) {
      showStatus("请填写方案名称", true);
      $("profileName").focus();
      return;
    }
    if (!apiKey) {
      showStatus("请填写 API Key", true);
      return;
    }

    if (isNewProfile) {
      const p = { id: genId(), name, apiKey, apiBaseUrl: apiBaseUrl || DEFAULTS.apiBaseUrl, modelName };
      profiles.push(p);
      activeId = p.id;
      isNewProfile = false;
    } else if (activeId) {
      const p = findActive();
      if (p) {
        p.name = name;
        p.apiKey = apiKey;
        p.apiBaseUrl = apiBaseUrl || DEFAULTS.apiBaseUrl;
        p.modelName = modelName;
      }
    } else {
      showStatus("请先选择或新建配置方案", true);
      return;
    }

    await persist();

    const sel = $("profileSelect");
    const placeholder = sel.querySelector('option[value=""]');
    if (placeholder) placeholder.remove();

    renderProfileSelect();
    $("profileNameField").style.display = "none";
    log.info("保存配置方案", { name, modelName });
    showStatus("✓ 已保存", false);
  }

  async function deleteProfile() {
    if (profiles.length <= 1) {
      showStatus("至少保留一个配置方案", true);
      return;
    }

    const p = findActive();
    if (!p) return;

    const confirmed = confirm(`确定要删除配置方案"${p.name}"吗？`);
    if (!confirmed) return;

    const idx = profiles.findIndex(x => x.id === activeId);
    if (idx === -1) return;

    profiles.splice(idx, 1);
    activeId = profiles[Math.min(idx, profiles.length - 1)].id;

    await persist();
    renderProfileSelect();
    loadFormFromProfile();
    log.info("已删除配置方案", { name: p.name });
    showStatus("已删除", false);
  }

  // ---- 测试连接 ----
  async function testConnection() {
    const apiKey = $("apiKey").value.trim();
    const apiBaseUrl = $("apiBaseUrl").value.trim().replace(/\/+$/, "");
    const modelName = $("modelName").value.trim();

    if (!apiKey || !apiBaseUrl || !modelName) {
      showTestResult("请先填写完整配置后再测试。", true);
      return;
    }

    const resultEl = $("testResult");
    const outputEl = $("testOutput");
    resultEl.classList.add("visible");
    outputEl.textContent = "连接中…";
    outputEl.className = "";

    const btn = $("testBtn");
    btn.disabled = true;
    btn.textContent = "测试中…";

    log.debug("测试连接", { apiBaseUrl, modelName });

    try {
      const response = await fetch(`${apiBaseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: modelName,
          messages: [
            {
              role: "user",
              content: "请回复'连接成功'这四个字，不要加其他内容。",
            },
          ],
          stream: false,
          max_tokens: 20,
        }),
      });

      if (!response.ok) {
        const text = await response.text();
        log.warn("测试连接失败", { status: response.status, detail: text.slice(0, 200) });
        showTestResult(
          `请求失败（${response.status} ${response.statusText}）：\n${text.slice(0, 500)}`,
          true
        );
        return;
      }

      const data = await response.json();
      const reply =
        data?.choices?.[0]?.message?.content ?? "(无返回内容)";
      log.info("测试连接成功", { apiBaseUrl, modelName });
      showTestResult(`✓ 连接成功\n\n模型返回：${reply}`, false);
    } catch (err) {
      log.error("测试连接异常", err.message);
      showTestResult(`连接失败：${err.message}`, true);
    } finally {
      btn.disabled = false;
      btn.textContent = "测试连接";
    }
  }

  function showStatus(msg, isError) {
    const el = $("statusMsg");
    el.textContent = msg;
    el.className = "status visible" + (isError ? " error" : "");
    setTimeout(() => {
      el.classList.remove("visible");
    }, 3000);
  }

  function showTestResult(text, isError) {
    const outputEl = $("testOutput");
    outputEl.textContent = text;
    outputEl.className = isError ? "test-error" : "";
  }

  // ---- 初始化 ----
  document.addEventListener("DOMContentLoaded", async () => {
    await loadFromStorage();
    renderProfileSelect();
    loadFormFromProfile();

    $("profileSelect").addEventListener("change", () => {
      const id = $("profileSelect").value;
      if (id) selectProfile(id);
    });

    $("newProfileBtn").addEventListener("click", newProfile);
    $("deleteProfileBtn").addEventListener("click", deleteProfile);
    $("saveBtn").addEventListener("click", saveProfile);
    $("testBtn").addEventListener("click", testConnection);
  });
})();